// ------------------------------------------------------------------------------------------------
// Copyright (c) Tomàs Forné Martínez. All rights reserved.
// ------------------------------------------------------------------------------------------------

table 96052 "Reference Index Rental Prices"
{
    Caption = 'Reference Index Rental Prices';
    DataPerCompany = false;

    fields
    {
        field(1; "Fixed Real Estate No."; Code[20])
        {
            Caption = 'Fixed Real Estate No.';
            DataClassification = ToBeClassified;
            TableRelation = "Fixed Real Estate";
        }
        field(2; "Line No."; Integer)
        {
            AutoIncrement = true;
            Caption = 'Line No.';
            DataClassification = ToBeClassified;
        }
        field(3; Date; Date)
        {
            DataClassification = ToBeClassified;
        }
        field(4; "Index Rental Price"; Decimal)
        {
            Caption = 'SERPAVI Min. Rental Price';
            DataClassification = ToBeClassified;

            trigger OnValidate()
            begin
                CalculateArea;
                RecalculatePrices();
            end;
        }
        field(5; "Area"; Decimal)
        {
            DataClassification = ToBeClassified;

            trigger OnValidate()
            begin
                RecalculatePrices();
            end;
        }
        field(6; "Index Rental Price Max."; Decimal)
        {
            Caption = 'SERPAVI Max. Rental Price';
            DataClassification = ToBeClassified;

            trigger OnValidate()
            begin
                CalculateArea;
                RecalculatePrices();
            end;
        }
        field(10; Price; Decimal)
        {
            Caption = 'SERPAVI Min. Price';
            DataClassification = ToBeClassified;
            Editable = false;
        }
        field(11; "Price Max."; Decimal)
        {
            Caption = 'SERPAVI Max. Price';
            DataClassification = ToBeClassified;
            Editable = false;
        }
        field(50; Active; Boolean)
        {
            DataClassification = ToBeClassified;

            trigger OnValidate()
            begin
                IF Rec.Active THEN BEGIN
                    ReferenceIndexRentalPrices.RESET;
                    ReferenceIndexRentalPrices.SETRANGE("Fixed Real Estate No.", Rec."Fixed Real Estate No.");
                    ReferenceIndexRentalPrices.SETFILTER("Line No.", '<>%1', Rec."Line No.");
                    IF ReferenceIndexRentalPrices.FINDSET THEN
                        ReferenceIndexRentalPrices.MODIFYALL(Active, FALSE);

                END;
            end;
        }
        field(100; Comments; Text[80])
        {
            DataClassification = ToBeClassified;
        }
    }

    keys
    {
        key(Key1; "Fixed Real Estate No.", "Line No.")
        {
            Clustered = true;
        }
    }

    fieldgroups
    {
    }

    trigger OnModify()
    begin
        // CalculateArea;
    end;

    var
        FixedRealEstate: Record "Fixed Real Estate";
        ReferenceIndexRentalPrices: Record "Reference Index Rental Prices";

    local procedure CalculateArea()
    begin
        IF FixedRealEstate.GET("Fixed Real Estate No.") THEN BEGIN
            FixedRealEstate.CALCFIELDS("Superficie construida");
            VALIDATE(Area, FixedRealEstate."Superficie construida")
        END;
    end;

    local procedure RecalculatePrices()
    begin
        Price := "Index Rental Price" * Area;
        "Price Max." := "Index Rental Price Max." * Area;
    end;
}

