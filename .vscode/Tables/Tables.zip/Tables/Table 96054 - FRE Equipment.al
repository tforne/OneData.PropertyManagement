// ------------------------------------------------------------------------------------------------
// Copyright (c) Tomàs Forné Martínez. All rights reserved.
// ------------------------------------------------------------------------------------------------

table 96054 "FRE Equipment"
{
    Caption = 'FRE Equipment';
    DataPerCompany = false;
    
    fields
    {
        field(1; "FRE No."; Code[20])
        {
            Caption = 'FRE No.';
            TableRelation = "Fixed Real Estate"."No.";
        }
        field(2; "Line No."; Integer)
        {
            Caption = 'Line No.';
        }
        field(3; Quantity; decimal)
        {
            Caption = 'Quantity';
            DecimalPlaces = 0 : 2;
        }
        field(6; Description; Text[50])
        {
            Caption = 'Description';

        }
        field(7; "Serial No."; Code[50])
        {
            Caption = 'Serial No.';
        }
        field(8; "Model No."; Code[50])
        {
            Caption = 'Model No.';
        }
        field(10; "Acquisition Date"; Date)
        {
            Caption = 'Acquisition Date';

        }
        field(11; "Acquisition Cost"; Decimal)
        {
            AutoFormatType = 1;
            BlankZero = true;
            Caption = 'Acquisition Cost';

        }
        field(12;"Equipment Warranty Period";Text[50])
        {
            Caption = 'Equipment Warranty Period';
        }
        field(20;"Need Maintenance?"; Boolean)
        {
            Caption = 'Need Maintenance?';
        }
        field(21;"Maintenance Contract No.";Code[20]    )
        {
            Caption = 'Maintenance Contract No.';
        }
    }

    keys
    {
        key(Key1; "FRE No.", "Line No.")
        {
            Clustered = true;
            MaintainSIFTIndex = false;
            SumIndexFields = "Acquisition Cost";
        }
    }

    fieldgroups
    {
    }

    trigger OnDelete()
    begin

    end;

    trigger OnInsert()
    begin

    end;

    trigger OnModify()
    begin
    end;

    var
        VATPostingSetup: Record "VAT Posting Setup";
        GenBusPostingGrp: Record "Gen. Business Posting Group";
        GenProdPostingGrp: Record "Gen. Product Posting Group";
        GLSetup: Record "General Ledger Setup";
        Currency: Record Currency;
        GLAcc: Record "G/L Account";
        ServLedgEntry: Record "Service Ledger Entry";
        LeaseContractHeader: Record "Lease Contract";
        LeaseContractLine: Record "Lease Contract Line";
        Text000: Label 'This service item does not belong to customer no. %1.';
        Text001: Label 'Service item %1 has a different ship-to code for this customer.\\Do you want to continue?';
        Text003: Label 'This service item already exists in this service contract.';
        Text008: Label '%1 field value cannot be later than the %2 field value on the contract line.';
        Text009: Label 'The %1 cannot be less than the %2.';
        Text011: Label 'Service ledger entry exists for service contract line %1.\\You may need to create a credit memo.';
        LeaseContractCommentLine: Record "Service Comment Line";
        LeaseContractHeaderAux: Record "Lease Contract";
        DimMgt: Codeunit "DimensionManagement";
        HideDialog: Boolean;
        StatusCheckSuspended: Boolean;
        Text013: Label 'You cannot change the %1 field on signed service contracts.';
        Text015: Label 'You cannot delete service contract lines on %1 service contracts.';
        Text016: Label 'Service contract lines must have at least a %1 filled in.';
        Text017: Label 'The %1 cannot be later than the %2.';
        Text018: Label 'You cannot reset %1 manually.';
        Text019: Label 'Service item %1 already belongs to one or more service contracts/quotes.\\Do you want to continue?';
        Text020: Label 'The service period for service item %1 under contract %2 has not yet started.';
        Text021: Label 'The service period for service item %1 under contract %2 has expired.';
        Text022: Label 'If you delete this contract line while the Automatic Credit Memos check box is not selected, a credit memo will not be created.\Do you want to continue?';
        Text023: Label 'The update has been interrupted to respect the warning.';
        UseServContractLineAsxRec: Boolean;
        Text024: Label 'You cannot enter a later date in or clear the %1 field on the contract line that has been invoiced for the period containing that date.';
        Text025: Label 'You cannot add a new %1 because the service contract has expired. Renew the %2 on the service contract.', Comment = 'You cannot add a new Service Item Line because the service contract has expired. Renew the Expiration Date on the service contract.';


    procedure HideDialogBox(Hide: Boolean)
    begin
        HideDialog := Hide;
    end;






}

