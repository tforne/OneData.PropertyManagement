page 96041 "OD Copy Lease Contract Req."
{
    PageType = StandardDialog;
    Caption = 'Copy Lease Contract from Another Company';
    ApplicationArea = All;

    layout
    {
        area(content)
        {
            group(Source)
            {
                Caption = 'Source';

                field(SourceCompanyName; SourceCompanyName)
                {
                    Caption = 'Source Company';
                    ApplicationArea = All;
                    TableRelation = Company.Name;
                }

                field(SourceContractNo; SourceContractNo)
                {
                    Caption = 'Source Contract No.';
                    ApplicationArea = All;

                    trigger OnLookup(var Text: Text): Boolean
                    var
                        LookupMgt: Codeunit "OD Lease Contract Lookup";
                        SelectedContractNo: Code[20];
                    begin
                        if SourceCompanyName = '' then
                            Error('Debes indicar primero la empresa origen.');

                        if LookupMgt.LookupContractFromCompany(SourceCompanyName, SelectedContractNo) then begin
                            SourceContractNo := SelectedContractNo;
                            exit(true);
                        end;

                        exit(false);
                    end;
                }
            }

            group(Options)
            {
                Caption = 'Options';

                field(CopyHeader; CopyHeader)
                {
                    Caption = 'Copy Header';
                    ApplicationArea = All;
                }

                field(CopyLines; CopyLines)
                {
                    Caption = 'Copy Lines';
                    ApplicationArea = All;
                }

                field(ReplaceLines; ReplaceLines)
                {
                    Caption = 'Replace Existing Lines';
                    ApplicationArea = All;
                    Editable = CopyLines;
                }

                field(CopyComments; CopyComments)
                {
                    Caption = 'Copy Comments';
                    ApplicationArea = All;
                }
            }
        }
    }

    var
        SourceCompanyName: Text[30];
        SourceContractNo: Code[20];
        ReplaceLines: Boolean;
        CopyHeader: Boolean;
        CopyLines: Boolean;
        CopyComments: Boolean;

    procedure SetDefaults()
    begin
        CopyHeader := true;
        CopyLines := true;
        ReplaceLines := true;
        CopyComments := false;
    end;

    procedure GetValues(var CopyRequest: Record "OD Copy Lease Contract Req.")
    begin
        CopyRequest.Init();
        CopyRequest."Source Company Name" := SourceCompanyName;
        CopyRequest."Source Contract No." := SourceContractNo;
        CopyRequest."Replace Lines" := ReplaceLines;
        CopyRequest."Copy Header" := CopyHeader;
        CopyRequest."Copy Lines" := CopyLines;
        CopyRequest."Copy Comments" := CopyComments;
    end;
}
